
# 1.0.1

First version with a NEWS file.

* Get rid of `R CMD check` warning for marked UTF-8 characters.

# 1.0.0

Last version without a NEWS file.
